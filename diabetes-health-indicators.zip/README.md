# 🩺 Diabetes Health Indicators Prediction

This project predicts whether a person has diabetes using health-related features from the **Behavioral Risk Factor Surveillance System (BRFSS 2015)** dataset. The notebook includes **data preprocessing, exploratory data analysis (EDA), feature engineering, and multiple classification models** to identify key health indicators that influence diabetes risk.

## 📘 Project Overview
- Conducted **data cleaning** and handled missing values  
- Performed **EDA** to understand feature relationships  
- Built **classification models** (Logistic Regression, Random Forest, Decision Tree, etc.)  
- Evaluated models using **accuracy, precision, recall, F1-score, and ROC-AUC**  
- Identified **important health features** correlated with diabetes outcomes  

## 📊 Dataset
- **File:** `diabetes_binary_5050split_health_indicators_BRFSS2015.csv`  
- **Source:** [CDC BRFSS 2015 Health Indicators](https://www.cdc.gov/brfss/)  

**Note:** The dataset is not uploaded to GitHub due to size. Download and place it in the `/data` folder.

## 📁 Repository Structure
```
diabetes-health-indicators/
│
├── notebooks/
│   └── Copy_of_Hussain.ipynb
├── data/
│   └── diabetes_binary_5050split_health_indicators_BRFSS2015.csv
├── requirements.txt
├── .gitignore
└── README.md
```

## ⚙️ Installation & Setup
```bash
git clone https://github.com/<your-username>/diabetes-health-indicators.git
cd diabetes-health-indicators
pip install -r requirements.txt
```

## ▶️ Running the Project
1. Place your dataset in the `data/` folder.  
2. Run the notebook in Jupyter:
   ```bash
   jupyter notebook notebooks/Copy_of_Hussain.ipynb
   ```

## 📈 Results Summary
- Random Forest achieved the highest accuracy.
- Key predictors included **BMI, Age, Physical Activity, and Blood Pressure**.

## 📬 Author
**Malik Sha Hussain**  
📧 your.email@example.com  
🔗 [LinkedIn](https://www.linkedin.com/in/your-profile)
